'use strict';

/**
 * blog-tag controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::blog-tag.blog-tag');
