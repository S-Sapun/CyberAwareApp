'use strict';

/**
 * blog-tag router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::blog-tag.blog-tag');
