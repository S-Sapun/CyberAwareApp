'use strict';

/**
 * blog-tag service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::blog-tag.blog-tag');
