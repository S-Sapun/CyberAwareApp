'use strict';

/**
 * course-progress controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::course-progress.course-progress');
