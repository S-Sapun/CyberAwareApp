'use strict';

/**
 * course-progress router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::course-progress.course-progress');
