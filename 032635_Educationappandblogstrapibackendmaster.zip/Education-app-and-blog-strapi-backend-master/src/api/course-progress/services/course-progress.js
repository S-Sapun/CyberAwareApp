'use strict';

/**
 * course-progress service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::course-progress.course-progress');
