'use strict';

/**
 * slider controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::slider.slider');
