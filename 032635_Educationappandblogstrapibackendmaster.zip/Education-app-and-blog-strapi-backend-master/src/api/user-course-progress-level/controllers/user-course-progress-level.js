'use strict';

/**
 * user-course-progress-level controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::user-course-progress-level.user-course-progress-level');
