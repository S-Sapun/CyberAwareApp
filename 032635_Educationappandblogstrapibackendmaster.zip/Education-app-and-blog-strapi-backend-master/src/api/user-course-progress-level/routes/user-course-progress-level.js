'use strict';

/**
 * user-course-progress-level router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::user-course-progress-level.user-course-progress-level');
