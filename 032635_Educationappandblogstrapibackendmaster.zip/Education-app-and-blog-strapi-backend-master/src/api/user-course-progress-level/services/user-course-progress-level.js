'use strict';

/**
 * user-course-progress-level service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::user-course-progress-level.user-course-progress-level');
