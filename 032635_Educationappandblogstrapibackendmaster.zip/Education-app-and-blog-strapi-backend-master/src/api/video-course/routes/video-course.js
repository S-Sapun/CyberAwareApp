'use strict';

/**
 * video-course router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::video-course.video-course');
