'use strict';

/**
 * video-course service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::video-course.video-course');
